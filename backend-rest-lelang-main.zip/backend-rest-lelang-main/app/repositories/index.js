const api = require('./api');
const userRepository = require('./userRepository');

module.exports = {
  api,
  userRepository
};
